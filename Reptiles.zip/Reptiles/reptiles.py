from animals import Animal

class Reptile (Animal):
    def __init__(self, name, terrain):
        """ an abstract class to represent reptiles.
        Reptiles can live in the swamp, in the sea, in the desert etc"""
        Animal.__init__(self, name, "Reptile")
        self.terrain = terrain
        #is this a sea or a landbound reptile, or both?

    def getTerrain(self):
        return self.terrain

    def setTerrain(self, terrain):
        self.terrain = terrain

    def toString(self):
        info = Animal.toString(self)
        info = info + "\nThis particular reptile lives " + self.getTerrain()
        return info

#~~~~~~~~~~~~~~~~~~~~~end of Reptile class~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

class Tortoise (Reptile):
    def __init__(self, name, terrain, subspecies):
        Reptile.__init__(self, name, terrain)
        self.subspecies = subspecies

    def getSubspecies(self):
        return self.subspecies

    def setSubspecies(self, subspecies):
        self.subspecies = subspecies

    def toString(self):
        info = Reptile.toString(self)
        info = info + " and it is a " + self.getSubspecies() + "."
        return info

#~~~~~~~~~~~~~~~~~~~~~~end of Tortoise class~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


