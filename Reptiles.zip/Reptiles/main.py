#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      cnys
#
# Created:     17/10/2014
# Copyright:   (c) cnys 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------

from animals import Animal
from animals import Dog
from animals import Bird
from animals import Hippo

def main():

    #start with the basic animal
    #the constructor needs params for name and species

    name = raw_input ("Name that animal!")
    species = raw_input ("What is it???")
    #normally you wouldn't do this as Animal would be abstract
    animal = Animal(name, species)

    #and test it.....
    #print animal.toString()

    name = raw_input ("Name that dog!")
    #we will assume by default that it is a motorbike chaser.
    dog = Dog(name, True)

    #and test it....remember it gets toString() from the Animal class
    #print dog.toString()

    name = raw_input ("Name that bird!")
    species = raw_input ("What is it???")
    cf = raw_input ("Hit X or x if it is a flightless bird!")
    if (cf == 'X') or (cf == 'x'):
        cf = False
    else:
        cf = True
    bird = Bird(name, species, cf)

    #print the bird.  This uses the toString() in Bird, not Animal
    #print bird.toString()

    hippo = Hippo("Harriet", "Dancer at the BBC")

    #putting the animals in a list
    zoo = [animal, dog, bird, hippo]

    for i in range (0, len(zoo)):
        print zoo[i].toString()










if __name__ == '__main__':
    main()
