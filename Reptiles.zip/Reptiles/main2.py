#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      cnys
#
# Created:     28/10/2014
# Copyright:   (c) cnys 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------

from reptiles import Tortoise


def main():
    tortoise = Tortoise("Munir", "in Chrissie's Garden", "wild Turkish tortoise")

    print tortoise.toString()

if __name__ == '__main__':
    main()
