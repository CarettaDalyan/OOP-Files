#-------------------------------------------------------------------------------
# Name:        Class files to demonsstrate Inheritance
# Purpose:
#
# Author:      cnys
#
# Created:     17/10/2014
# Copyright:   (c) cnys 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------

class Animal():
    """a generic classs that represents animals.
    This will eventually be an ABSTRACT class, which is only used
    to create members of the subclasses"""
    def __init__(self, name, species):
       self.name = name
       self.species = species

    #getters and setters next

    def getName(self):
        return self.name

    def getSpecies(self):
        return self.species

    def setName(self, name):
        self.name = name

    def setSpecies (self, species):
        self.species = species

    #and the usual toString()

    def toString(self):
        info = "This animal is called "
        info = info + self.getName()
        info = info + " and it is a "
        info = info + self.getSpecies()
        return info

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

class Dog(Animal):
    """ a more specialised class just for dogs"
    ALL dogs have the species "dog" and we have also included
    whether it likes to chase motorbikes.  It has it's own __init__ method
    and this is an example of OVERRIDING.
    When creating a DOG object, we now need only parameters for
    name and chases_motorbikes, because the species is filled in by default."""

    def __init__(self, name, chases_motorbikes):
        Animal.__init__(self, name, "dog")
        #note that we call the Animal __init__ here
        #then set the new attribute
        self.chases_motorbikes = True

    def chaseMotorbikes (self):
        return self.chases_motorbikes

    def setChasesBikes(self, boolean):
        self.chases_motorbikes = boolean

    def getChasesBikes (self):
        return self.chases_motorbikes

    def toString(self):
        info = Animal.toString(self)
        info = info + "\n"
        if self.chases_motorbikes == True:
            info = info + self.getName() + " likes to chase motorbikes."
        return info



#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

class Bird(Animal):
    """another inherited class to represent birds"""
    def __init__(self, name, species, can_fly):
        Animal.__init__(self, name, species)
        self.can_fly = can_fly

    def getCanFly(self):
        return self.can_fly

    def setCanFly(self, boolean):
        """ask for True or False to see whether this is a flying
        or a flightless bird
        (bool) -> none"""
        self.can_fly = boolean

    def toString(self):
        info = "This bird is called " + self.getName() + " and it is a "
        info = info + self.getSpecies() + ".\n"
        if self.getCanFly() == True:
            info = info + self.getName() + " can fly."
        else:
            info = info + self.getName() + " cannot fly."
        return info

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

class Hippo (Animal):
    """another derived class that represents a specialised animal"""
    def __init__(self, name, job):
    #specialist hippo constructor
        Animal.__init__(self, name, "Hippo")
        #generic Animal constructor
        self.job = job

    #now add specific Hippo stuff
    def getJob(self):
        #some Hippos are gainfully employed, for example
        #the ones that dance during bumper breaks
        #at the BBC.
        return self.job

    def setJob(self, job):
        self.job = job

    def toString(self):
        info = Animal.toString(self)
        #start out with the Animal toString() then add the hippo bits on
        info = info + " and this hippo works as a " + self.getJob()
        return info























