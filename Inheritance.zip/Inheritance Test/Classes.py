#-------------------------------------------------------------------------------
# Name:        VirtualPet
# Purpose:
#
# Author:      cnys
#
# Created:     08/09/2015
# Copyright:   (c) cnys 2015
# Licence:     <your licence>
#-------------------------------------------------------------------------------
class Tamagochi:
    """A class to simulate a virtual pet that you can play with
    >>>VirtualPet()
    VirtualPetType"""

    def __init__(self):
        """Virtual Pet Contructor
        define the attributes first"""
        self.Name = "nameless"
        self.LifeRemaining = 25
        self.HowClean = 10
        self.Fed = 10
        self.Entertained = 10
        self.Happiness = (self.LifeRemaining + self.HowClean + self.Fed + self.Entertained)
        self.Alive = True

    def setName(self, newname):
        """Gives the virtual pet a name
        >>>setName("Toothless")
        Fido"""
        self.Name = newname

    def getName(self):
        return self.Name

    def toString(self):
        info = "This tamagochi is called " + self.Name
        info = info + " and " + self.Name + " has " +  str(self.Fed)+ " food points."
        info = info +"\n" +"Their happiness rating is " + str(self.Happiness)
        return info

    def Feed(self, foodstuff, points):
        """A hybrid method to feed the tamagochi
        >>>Feed("Broccoli", 10)
        NoneType"""
        if self.Alive:
            self.Fed += points
            return ("This tamagochi has just eaten some " + foodstuff)

    def getFed(self):
        return self.Fed

    def getHappiness(self):
        self.Happiness = (self.LifeRemaining + self.HowClean + self.Fed + self.Entertained)
        if self.Happiness > 50:
            return ("I am very happy! :D because I have " + str(self.Happiness))
        elif self.Happiness > 35:
            return ("Meh :| I only have " + str(self.Happiness))
        elif self.Happiness > 10:
            return ("I am very displeased :( why have I only got " + str(self.Happiness) )
        else:
             return ("Boo! Hiss! >:-(  I need more than " + str(self.Happiness))

    def isAlive(self):
        if self.Happiness < 0:
            self.Alive = False
        return self.Alive

    def Bath(self):
        """Tamagochis do not like water....."""
        self.Happiness -= 15
        self.HowClean += 20

    def playFootball(self):
        self.Happiness += 30
        self.HowClean -= 10
        self.Fed -= 10
        self.Entertained += 20

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

class TankCommander(Tamagochi):
    """This subclass INHERITS from Tamagochi as it is a TYPE OF.."""
    def __init__(self):
        Tamagochi.__init__(self)
        #now I can start adding the extra parts
        self.drives_tank = True
        self.Weapons = 50

    def getDrivesTank(self):
        return self.drives_tank

    def getWeapons(self):
        return self.Weapons

    def toString(self):
        info = Tamagochi.toString(self)
        info = info + "\n"
        if self.drives_tank:
            info = info + "And " + self.Name + " likes to drive his tank."
        return info

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

class Hairdresser (Tamagochi):

    def __init__(self):
        Tamagochi.__init__(self)

    def toString(self):
        info = Tamagochi.toString(self)
        info = info + "\n" + self.Name + " will give you a nice shampoo and blow dry."
        return info

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class Beautician (Hairdresser):

    def __init__(self):
        Hairdresser.__init__(self)

    def toString(self):
        info = Hairdresser.toString(self)
        info = info + "\nAnd you can also get your nails done by " + self.Name + "."
        return info

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class Spy (TankCommander):

    def __init__(self):
        TankCommander.__init__(self)
        self.languages = ["Czech", "Hebrew", "Japanese", "Gaelic"]

    def sayHello(self, lang):
        """Send a string parameter to say Hello to the spy.
        >>>sayHello("Japanese")
        'Konichiwa'"""
        hello = ["Ahoj", "????", "Konichiwa", "Feas gu mhath"]
        if lang in self.languages:
            index = self.languages.index(lang)
            return hello[index]
        else:
            return "Non capiche."

    def toString(self):
        info = TankCommander.toString(self)
        info = info + "\nBut only when he is not on a Secret Spying Mission for his clan."
        return info












