#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      CNYS
#
# Created:     07/10/2015
# Copyright:   (c) CNYS 2015
# Licence:     <your licence>
#-------------------------------------------------------------------------------
from Tamagochi import Tamagochi
from Tamagochi import TankCommander
from Tamagochi import Hairdresser

def main():
    t = Tamagochi()
    t.setName("Biffo")

    c = TankCommander()
    c.setName ("Gary")

    h = Hairdresser()
    h.setName("Audrey")

    village = []
    village.append(t)
    village.append(c)
    village.append(h)
    for i in range (0, len(village)):
        print village[i].toString()

    print village[1].Feed("carrots", 5)

    for i in range (0, len(village)):
        print village[i].toString()




if __name__ == '__main__':
    main()
