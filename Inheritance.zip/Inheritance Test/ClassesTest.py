#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      CNYS
#
# Created:     07/10/2015
# Copyright:   (c) CNYS 2015
# Licence:     <your licence>
#-------------------------------------------------------------------------------
from Classes import Tamagochi
from Classes import TankCommander
from Classes import Hairdresser
from Classes import Beautician
from Classes import Spy

def main():

    t = Tamagochi()
    t.setName("Biffo")

    c = TankCommander()
    c.setName("Gary")

    h = Hairdresser()
    h.setName("Audrey")

    b = Beautician()
    b.setName("Bernice")

    s = Spy()
    s.setName("007")

    clan = []
    clan.append(t)
    clan.append(c)
    clan.append(h)
    clan.append(b)
    clan.append(s)

    for j in range (0, len(clan)):
        print clan[j].toString()
        if isinstance(clan[j], Spy):
            #if it is a member of a particular class
            print s.sayHello("Hebrew")
        if isinstance(clan[j], TankCommander):
            print clan[j].getDrivesTank()





if __name__ == '__main__':
    main()
