#-------------------------------------------------------------------------------
# Name:        VirtualPet
# Purpose:
#
# Author:      cnys
#
# Created:     08/09/2015
# Copyright:   (c) cnys 2015
# Licence:     <your licence>
#-------------------------------------------------------------------------------
class Tamagochi:
    """A class to simulate a virtual pet that you can play with
    >>>VirtualPet()
    VirtualPetType"""

    def __init__(self):
        """Virtual Pet Contructor
        define the attributes first"""
        self.Name = "nameless"
        self.LifeRemaining = 25
        self.HowClean = 10
        self.Fed = 10
        self.Entertained = 10
        self.Happiness = (self.LifeRemaining + self.HowClean + self.Fed + self.Entertained)
        self.Alive = True

    def setName(self, newname):
        """Gives the virtual pet a name
        >>>setName("Toothless")
        Fido"""
        self.Name = newname

    def getName(self):
        return self.Name

    def toString(self):
        info = "This tamagochi is called " + self.Name
        info = info + " and " + self.getName() + " has " +  str(self.Fed)+ " food points."
        info = info + "\n"  + self.getName() + " has a happiness rating of " + str(self.Happiness)
        return info

    def Feed(self, foodstuff, points):
        """A hybrid method to feed the tamagochi
        >>>Feed("Broccoli", 10)
        NoneType"""
        if self.Alive:
            self.Fed += points
            return ("This tamagochi has just eaten some " + foodstuff)

    def getFed(self):
        return self.Fed

    def getHappiness(self):
        self.Happiness = (self.LifeRemaining + self.HowClean + self.Fed + self.Entertained)
        if self.Happiness > 50:
            return ("I am very happy! :D because I have " + str(self.Happiness))
        elif self.Happiness > 35:
            return ("Meh :| I only have " + str(self.Happiness))
        elif self.Happiness > 10:
            return ("I am very displeased :( why have I only got " + str(self.Happiness) )
        else:
             return ("Boo! Hiss! >:-(  I need more than " + str(self.Happiness))

    def isAlive(self):
        if self.Happiness < 0:
            self.Alive = False
        return self.Alive

    def Bath(self):
        """Tamagochis do not like water....."""
        self.Happiness -= 15
        self.HowClean += 20

    def playFootball(self):
        self.Happiness += 30
        self.HowClean -= 10
        self.Fed -= 10
        self.Entertained += 20

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

class TankCommander(Tamagochi):
    """A specialised class just for Tamagochi Tank Commanders."""

    def __init__(self):
        Tamagochi.__init__(self)
        #add in the constructor for the superclass
        #add in at this point the special attributes for the tank commander
        self.drives_tank = True
        self.Weaponry = 50

    def getDrivesTank(self):
        return self.drives_tank

    def getWeponry(self):
        return self.Weaponry

    def toString(self):
        info = Tamagochi.toString(self)
        info = info + "\n"
        if self.drives_tank == True:
            info = info + self.getName() + " likes to drive a wee tank."
        return info

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

class Hairdresser (Tamagochi):

    def __init__(self):
        Tamagochi.__init__(self)
        self.usesTongs = True
        self.Happiness += 25

    def toString(self):
        info = Tamagochi.toString(self)
        info = info + " \n" + self.getName() + " is very happy.  She will give you a nice cut and blow dry."
        return info





























