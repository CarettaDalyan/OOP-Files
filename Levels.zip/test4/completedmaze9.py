#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      cnys
#
# Created:     17/11/2015
# Amended for Python 3 14/11/2017
# Copyright:   (c) cnys 2015, 2017
# Licence:     <your licence>
#-------------------------------------------------------------------------------
class CompletedMaze:

     def __init__(self):
        self.cmaze = [[]]

     def getLevel1(self, char, row, col):
        self.cmaze = [['#','#','#','#','#','#','#'],
                       ['#',' ','^',' ',' ',' ','#'],
                       ['#',' ',' ',' ',' ',' ','#'],
                       ['#',' ',' ',' ',' ',' ','#'],
                       ['#',' ',' ',' ',' ',' ','#'],
                       ['#',' ',' ',' ',' ',' ','#'],
                       ['#','#','#','#','#','#','#']]
        self.cmaze [row][col] = char
        return self.cmaze

     
     def getLevel2(self, char, row, col):
        self.cmaze = [['#','#','#','#','#','#','#'],
               ['#',' ','#',' ',' ',' ','#'],
               ['#',' ','#',' ',' ',' ','#'],
               ['#',' ',' ',' ',' ','#','#'],
               ['#',' ','#',' ',' ',' ','#'],
               ['#',' ','#',' ',' ',' ','#'],
               ['#','#','#','#','#','#','#']]
        self.cmaze [row][col] = char
        return self.cmaze

     
     def getLevel3(self, char, row, col):
        self.cmaze = [['#','#','/','#','#','#','#','#'],
               ['#',' ','#',' ',' ',' ','#', "/"],
               ['#',' ','#',' ',' ',' ',' ', '#'],
               ['#',' ',' ',' ',' ','#','#', '/'],
               ['#',' ',' ',' ',' ',' ',' ', '#'],
               ['/','#',' ','#',' ',' ','#', '/'],
               ['#','#','#','/','#','#','#', '#']]
        self.cmaze [row][col] = char
        return self.cmaze

     
     def getCurrentMaze(self):
        return self.cmaze

     def toString(self):
        """prints out the maze"""
        printme = ""
        for i in range (0,len(self.cmaze)):
            for j in self.cmaze[i]:
                printme = printme + j
            printme = printme + "\n"
        return printme

     def clearAtPos(self, row, col):
        self.cmaze[row][col] = " "

        
     def placeRat (self, rat_char, row, column):
        """places a rat at a specified row and column in the maze
	(char, int, int) -> none
        >>>placeRat("$", 2, 2)
        NoneType"""

        self.cmaze[row][column] = rat_char








