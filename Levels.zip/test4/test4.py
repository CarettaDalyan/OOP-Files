#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      CNYS
#
# Created:     03/11/2015
# Copyright:   (c) CNYS 2015
# Licence:     <your licence>

#I have made a new class, called "CompletedMaze".  This shows the maze as it
#should appear when the level is finished.
#I have added another part to the main game loop so that it checks whether
#the current maze == the completed maze.  If it does, then that level is finished.
#As this is going to get quite big by the time I do 5 levels, you might want to
#take it out into a separate function.
#I have also had to place the rat in the completed maze as he may be in a different
#finishing position every time.
#I also had to add a "get current maze" method to my Maze to get this to work :0
#I've only done levels 1 2 and 3 of this, it might be good practice for you to
#complete it for yourselves.
#-------------------------------------------------------------------------------
#class imports
from maze4 import Maze
from rat2 import Rat
from completedmaze9 import CompletedMaze

#add in the pygame imports
import random, sys, copy, os, pygame
from pygame.locals import *

maze = Maze()
rat = Rat("^", 4, 1)
cmaze = CompletedMaze()

FPS = 30                    # frames per second to update the screen
WINWIDTH = 800              # width of the program's window, in pixels
WINHEIGHT = 600             # height in pixels
HALF_WINWIDTH = int(WINWIDTH / 2) #you need to know 1/2 sizes so you can
HALF_WINHEIGHT = int(WINHEIGHT / 2) #place things centrally

# The total width and height of each tile in pixels.
TILEWIDTH = 32
TILEHEIGHT = 32
TILEFLOORHEIGHT = 32

BRIGHTBLUE = (  0, 170, 255)
WHITE      = (255, 255, 255)
BGCOLOR = BRIGHTBLUE
TEXTCOLOR = WHITE

#A dictionary of the images used.  You can then use#floor, wall etc
#in place of the whole pathname

IMAGESDICT = {'floor': pygame.image.load("Images/floor.gif"),
              'wall': pygame.image.load("Images/wall.gif"),
              'sprout': pygame.image.load("Images/sprout.gif"),
              'rat': pygame.image.load("Images/rat.gif"),
              'gold': pygame.image.load("Images/goldensprout.gif"),
              'spacer': pygame.image.load("Images/spacer.gif") }

TILEMAPPING = { '#':IMAGESDICT['wall'],
                ' ':IMAGESDICT['floor'],
                '@':IMAGESDICT['sprout'],
                '/':IMAGESDICT['spacer'],
                '%':IMAGESDICT['gold'],
                '^':IMAGESDICT['rat']}

pygame.init()
FPSCLOCK = pygame.time.Clock()
DISPLAYSURF = pygame.display.set_mode((WINWIDTH, WINHEIGHT))
pygame.display.set_caption('Rat Maze v 7.00')
BASICFONT = pygame.font.Font('freesansbold.ttf', 18)

level = 1

def moveRatLeft():
    #moving the rat to the left....
    #BEFORE you move the rat, check he CAN move!
    x = maze.getCharAtPos(rat.getRow(), rat.getCol() - 1)
    if x == "#":
        #print "This is a wall!"
        pass
    else:
        #if it is not a wall, maybe it is a tasty sprout?
        if x == "@":
            #print "Yum yum! Dinner time!"
            rat.eatSprouts()
            maze.eatSprouts()
        maze.clearAtPos(rat.getRow(), rat.getCol())
        rat.moveLeft()
        maze.placeRat(rat.getChar(), rat.getRow(), rat.getCol())
    print (maze.toString())
    print (rat.toString())


def moveRatRight():
    #moving the rat to the right....
    #BEFORE you move the rat, check he CAN move!
    x = maze.getCharAtPos(rat.getRow(), rat.getCol() + 1)
    if x == "#":
        #print "This is a wall!"
        pass
    else:
        #if it is not a wall, maybe it is a tasty sprout?
        if x == "@":
            #print "Yum yum! Dinner time!"
            rat.eatSprouts()
            maze.eatSprouts()
        maze.clearAtPos(rat.getRow(), rat.getCol())
        rat.moveRight()
        maze.placeRat(rat.getChar(), rat.getRow(), rat.getCol())
    print (maze.toString())
    print (rat.toString())

#define functions for moveRatUp() moveRatDown() moveRatLeft()

def moveRatUp():
    #moving the rat to the right....
    #BEFORE you move the rat, check he CAN move!
    x = maze.getCharAtPos(rat.getRow()-1, rat.getCol())
    if x == "#":
        print ("This is a wall!")
    else:
        #if it is not a wall, maybe it is a tasty sprout?
        if x == "@":
            print ("Yum yum! Dinner time!")
            rat.eatSprouts()
            maze.eatSprouts()
        maze.clearAtPos(rat.getRow(), rat.getCol())
        rat.moveUp()
        maze.placeRat(rat.getChar(), rat.getRow(), rat.getCol())
    print (maze.toString())
    print (rat.toString())

def moveRatDown():
    #moving the rat to the right....
    #BEFORE you move the rat, check he CAN move!
    x = maze.getCharAtPos(rat.getRow()+1, rat.getCol())
    if x == "#":
        print ("This is a wall!")
    else:
        #if it is not a wall, maybe it is a tasty sprout?
        if x == "@":
            print ("Yum yum! Dinner time!")
            rat.eatSprouts()
            maze.eatSprouts()
        maze.clearAtPos(rat.getRow(), rat.getCol())
        rat.moveDown()
        maze.placeRat(rat.getChar(), rat.getRow(), rat.getCol())
    print (maze.toString())
    print (rat.toString())

def main():
    global FPSCLOCK, DISPLAYSURF, IMAGESDICT, TILEMAPPING, BASICFONT, level
    maze.placeRat('^', 4,1)     #make this match where the rat is created
    print (maze.toString())
    #maze.generateRandomItem()
    drawMap(maze)

    while True:

        #thread 1 - look for an action
        for event in pygame.event.get(): # event handling loop
            if event.type == QUIT:
                # Player clicked the "X" at the corner of the window.
                terminate()
            elif event.type == KEYDOWN:
                if event.key == K_RIGHT:
                    moveRatRight()
                elif event.key == K_UP:
                    moveRatUp()
                elif event.key == K_LEFT:
                    moveRatLeft()
                elif event.key == K_DOWN:
                    moveRatDown()
                elif event.key == K_SPACE:
                    restart()
                elif event.key == K_CAPSLOCK:
                    maze.goToLevel2()
                    maze.placeRat("^", 4, 1)
                    rat.setCol(1)
                    rat.setRow(4)
                    drawMap(maze)
                elif event.key == K_z:
                    maze.goToLevel3()
                    maze.placeRat("^", 4, 1)
                    rat.setCol(1)
                    rat.setRow(4)
                    drawMap(maze)
                elif event.key == K_f:
                    maze.goToLevel4()
                    maze.placeRat("^", 4, 1)
                    rat.setCol(1)
                    rat.setRow(4)
                    drawMap(maze)
                elif event.key == K_p:
                    maze.goToLevel5()
                    maze.placeRat("^", 4, 1)
                    rat.setCol(1)
                    rat.setRow(4)
                    drawMap(maze)
                else:
                    pass
            mapNeedsRedraw = True


        #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #here is where we check whether the level is complete!

            if (level == 1):
                if (maze.getCurrentMaze() == cmaze.getLevel1("^", rat.getRow(), rat.getCol())):
                    #level is completed
                    print ("Level completed!")
                    maze.goToLevel2()
                    rat.setRow(4)
                    rat.setCol(1)
                    maze.placeRat("^",4,1)
                    level = 2
            elif (level == 2):
                if (maze.getCurrentMaze() == cmaze.getLevel2("^", rat.getRow(), rat.getCol())):
                   #level 2 is completed
                   print ("Level 2 complete!")
                   maze.goToLevel3()
                   print (cmaze.toString())
                   rat.setRow(4)
                   rat.setCol(1)
                   maze.placeRat("^",4,1)
                   level = 3
            elif (level == 3):
                print (cmaze.toString())
                if (maze.getCurrentMaze() == cmaze.getLevel3("^", rat.getRow(), rat.getCol())):
                   #level 3 is completed
                   print ("Level 3 complete!")
                   maze.goToLevel4()
                   rat.setRow(4)
                   rat.setCol(1)
                   maze.placeRat("^",4,1)
                   level = 4


        #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        #thread 2: redraw the screen
        DISPLAYSURF.fill(BGCOLOR) #draws the turquoise background
        #if something has changed, redraw....
        if mapNeedsRedraw:
            mapSurf = drawMap(maze)
            mapNeedsRedraw = False

        mapSurfRect = mapSurf.get_rect()
        mapSurfRect.center = (HALF_WINWIDTH, HALF_WINHEIGHT)

        # Draw the map on the DISPLAYSURF object.
        DISPLAYSURF.blit(mapSurf, mapSurfRect)

        pygame.display.update() # draw DISPLAYSURF to the screen.
        FPSCLOCK.tick()

def drawMap(maze):
    #draw the tile sprites onto this surface.
    #this creates the visual map!
    mapSurfWidth = maze.getWidth() * TILEWIDTH
    mapSurfHeight = maze.getHeight() * TILEHEIGHT
    mapSurf = pygame.Surface((mapSurfWidth, mapSurfHeight))
    mapSurf.fill(BGCOLOR)
    for h in range(maze.getHeight()):
        for w in range(maze.getWidth()):
            thisTile = pygame.Rect((w * TILEWIDTH, h * TILEFLOORHEIGHT, TILEWIDTH, TILEHEIGHT))
            if maze.getCharAtPos(h, w) in TILEMAPPING:
                #checks in the TILEMAPPING directory above to see if there is a
                #matching picture, then renders it
                baseTile = TILEMAPPING[maze.getCharAtPos(h,w)]

            # Draw the tiles for the map.
            mapSurf.blit(baseTile, thisTile)
    return mapSurf

def restart():
    maze.__init__()
    rat.setRow(4)
    rat.setCol(1)
    maze.placeRat(rat.getChar(), rat.getRow(), rat.getCol())
    drawMap(maze)

def restartLevel(level):
    if level == 2:
        maze.goToLevel2()
        rat.setRow(4)
        rat.setCol(1)
        maze.placeRat(rat.getChar(), rat.getRow(), rat.getCol())
        drawMap(maze)


def terminate():
    #shutdown routine
    pygame.quit()
    sys.exit()












if __name__ == '__main__':
    main()
