#-------------------------------------------------------------------------------
# Name:        maze
# Purpose:
#
# Author:      cnys
#
# Created:     26/09/2014
# Checked for compatibility with Python 3 on 14/11/2017
# Copyright:   (c) cnys 2014, 2017
# Licence:     <your licence>
#-------------------------------------------------------------------------------
import random

class Maze:
    """ A 2D maze. """

    def __init__(self):
        """the maze constructor"""
        self.maze = [['#','#','#','#','#','#','#'],
                       ['#',' ','@',' ',' ',' ','#'],
                       ['#',' ',' ',' ',' ',' ','#'],
                       ['#',' ',' ',' ',' ',' ','#'],
                       ['#',' ',' ',' ',' ',' ','#'],
                       ['#',' ',' ',' ',' ',' ','#'],
                       ['#','#','#','#','#','#','#']]
        self.sprouts = 1
        self.width = 7
        self.height = 7

    def toString(self):
        """prints out the maze
	(none) -> none"""
        printme = ""
        for i in range (0,len(self.maze)):
            for j in self.maze[i]:
                printme = printme + j
            printme = printme + "\n"
        return printme

    def placeRat (self, rat_char, row, column):
        """places a rat at a specified position in the maze
	(char, int, int) -> none
        >>>placeRat("$", 2, 2)
        NoneType"""
        self.maze[row][column] = rat_char

    def clearAtPos(self, row, col):
        self.maze[row][col] = " "

    def getCharAtPos(self, row, col):
        """This is a very important method as it allows you to check for
        walls, sprouts and attractive other rats of the opposite (or same) sex.
        >>>getCharAtPos(0,0)
        '#'"""
        return self.maze[row][col]

    def eatSprouts(self):
        self.sprouts -= 1

    def goToLevel2(self):
        self.maze = [['#','#','#','#','#','#','#'],
               ['#',' ','#',' ',' ','@','#'],
               ['#',' ','#',' ',' ',' ','#'],
               ['#',' ',' ','@',' ','#','#'],
               ['#',' ','#',' ',' ',' ','#'],
               ['#',' ','#',' ',' ','@','#'],
               ['#','#','#','#','#','#','#']]
        self.sprouts =3
        self.width = 7
        self.height = 7

    def getWidth(self):
        return self.width

    def getHeight(self):
        return self.height

    def generateRandomSprout(self):
        x = random.randint(1,5)
        y = random.randint(1,5)
        self.maze[x][y] = '@'

    def generateRandomItem(self):
        items = ['#', '@', '%', '@', '#']
        x = random.randint(1,5)
        y = random.randint(1,5)
        z = random.randint(0,4)
        item = items[z]
        if self.maze[x][y] == " ":
            self.maze[x][y] = item
        if item == "@":
            self.sprouts +=1
        if item == '%':
            self.sprouts += 1

    def goToLevel3(self):
        self.maze = [['#','#','/','#','#','#','#','#'],
               ['#',' ','#',' ',' ','@','#', "/"],
               ['#',' ','#',' ',' ',' ',' ', '#'],
               ['#',' ',' ','@',' ','#','#', '/'],
               ['#',' ',' ',' ',' ',' ',' ', '#'],
               ['/','#',' ','#',' ','@','#', '/'],
               ['#','#','#','/','#','#','#', '#']]
        self.sprouts =3
        self.width = 8
        self.height = 7

    def goToLevel4(self):
        self.maze = [['#','#','/','#','#','#','#','#'],
               ['#',' ','#',' ',' ','@','#', "/"],
               ['#',' ','#',' ',' ',' ',' ', '#'],
               ['#','@',' ','@',' ','#','#', '/'],
			   ['#',' ',' ',' ',' ','#',' ', '#'],
               ['#',' ',' ',' ',' ',' ',' ', '#'],
               ['/','#',' ','#',' ','@','#', '/'],
               ['#','#','#','/','#','#','#', '#']]
        self.sprouts =4
        self.width = 8
        self.height = 8

    def goToLevel5(self):
        self.maze = [['#','#','/','#','#','#','#','#', '#', '#'],
               ['#',' ','#',' ',' ','@','#',' ', '#', "/"],
               ['#',' ','#',' ',' ',' ',' ', ' ',' ','#'],
               ['#','@',' ','@',' ','#','#',' ', '#', '/'],
			   ['#',' ',' ',' ',' ','#',' ', ' ', '#', '/'],
               ['#',' ',' ',' ',' ','#',' ',' ', '#','/'],
               ['#',' ',' ',' ',' ','#',' ', '#', ' ', '#'],
               ['#',' ',' ',' ',' ',' ',' ', ' ',' ', '#'],
               ['/','#',' ','#',' ','@','#', ' ', '#', '/'],
               ['#','#','#','/','#','#','#', '#', '#', '/']]
        self.sprouts =4
        self.width = 10
        self.height = 10

    def getCurrentMaze(self):
        return self.maze

